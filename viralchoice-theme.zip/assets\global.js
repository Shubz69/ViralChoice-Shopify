// Basic global JavaScript for Shopify theme
// This file is required by theme.liquid

console.log('ViralChoice theme loaded');
